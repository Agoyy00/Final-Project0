package projectakhir;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import static java.lang.System.err;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Yoga Pandu N
 */
public class Koneksi {
    public static Connection conn;
    public static Statement stm;
    public static Connection getConnection(){
        if(conn==null){
            try{
            String url = "jdbc:mysql://localhost:3306/db_project";
            String user = "root";
            String pass = "";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = (Connection) DriverManager.getConnection(url,user,pass);
            stm = (Statement) conn.createStatement();
            JOptionPane.showMessageDialog(null, "Berhasil Koneksi");
            
        }catch(Exception e){
                System.err.println("Koneksi Gagal" + e.getMessage());
                }
    }
        return conn;
   }
}