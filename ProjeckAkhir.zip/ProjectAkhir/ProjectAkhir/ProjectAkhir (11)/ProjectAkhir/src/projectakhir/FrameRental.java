/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projectakhir;

import projectakhir.FrameMenu;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.*;
import projectakhir.TambahProduk;
import javax.swing.table.DefaultTableModel;
import java.util.Vector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Yoga Pandu N
 */

class Penjualan{
        private int idPenjualan;
        private int idProduk;
        private String namaProduk;
        private String tipeProduk;
        private int harga;
        private int jumlahBayar;
        private int sisaBayar;
        
        
        public Penjualan(int idPenjualan, int idProduk, String namaProduk, String tipeProduk, int harga, int jumlahBayar, int sisaBayar) {
            this.idPenjualan = idPenjualan;
            this.idProduk = idProduk;
            this.namaProduk = namaProduk;
            this.tipeProduk = tipeProduk;
            this.harga = harga;
            this.jumlahBayar = jumlahBayar;
            this.sisaBayar = sisaBayar;
        }

        /**
         * @return the idMerk
         */
        public int getIdProduk() {
            return this.idProduk;
        }

        public int getHarga(){
            return this.harga;
        }

    /**
     * @return the idPenjualan
     */
    public int getIdPenjualan() {
        return idPenjualan;
    }

    /**
     * @return the tglPenjualan
     */
    public String getTipeProduk() {
        return tipeProduk;
    }
    
    public String getNamaProduk(){
        return namaProduk;
    }

    /**
     * @return the jumlahBayar
     */
    public int getJumlahBayar() {
        return jumlahBayar;
    }

    /**
     * @return the sisaBayar
     */
    public int getSisaBayar() {
        return sisaBayar;
    }
    
    public void setSisaBayar(int sisaBayar){
        this.sisaBayar = sisaBayar;
    }

    /**
     * @return the status
     */

        /**
         * @return the namaProduk
         */
        
    }

public class FrameRental extends javax.swing.JFrame {
    
    public static Connection conn;
    public static Statement stm;
    String url, user, pass;
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    public static ResultSet res;
    
    private DefaultTableModel tableModel;

    public FrameRental() {
        initComponents();
        load_table();
        TampilTabel();
        setResizable(false);
        
        url = "jdbc:mysql://localhost:3306/db_project";
        user = "root";
        pass = "";

        try {
            con = DriverManager.getConnection(url, user, pass);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(new JFrame(), ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
        
    }

     public class Koneksi {
    public static Connection getConnection(){
        if(conn==null){
            try{
            String url = "jdbc:mysql://localhost:3306/db_project";
            String user = "root";
            String pass = "";
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = (Connection) DriverManager.getConnection(url,user,pass);
            stm = (Statement) conn.createStatement();
            JOptionPane.showMessageDialog(null, "Berhasil Koneksi");
            
        }catch(Exception e){
                System.err.println("Koneksi Gagal" + e.getMessage());
                }
    }
        return conn;
   }
}
    public void TampilTabel(){
        DefaultTableModel tb = new DefaultTableModel();
        tb.addColumn("id");
        tb.addColumn("id_produk");
        tb.addColumn("nama_produk");
        tb.addColumn("tipe_produk");
        tb.addColumn("harga");
        tb.addColumn("jumlah_bayar");
        tb.addColumn("sisa_bayar");
        jTable1.setModel(tb);
        
        try{
        res = stm.executeQuery("SELECT tp.id, tp.id_produk, pr.nama_produk, pr.tipe_produk, pr.harga, tp.jumlah_bayar FROM tab_penjualan tp JOIN tab_produk pr ON tp.id_produk = pr.id");
        while (res.next()){
            int harga = res.getInt("harga");
            int jumlahBayar = res.getInt("jumlah_bayar");
            int sisaBayar = jumlahBayar - harga;
            tb.addRow(new Object[]{
            res.getString("id"),
            res.getString("id_produk"),
            res.getString("nama_produk"),
            res.getString("tipe_produk"),
            harga,
            jumlahBayar,
            sisaBayar
            });
        }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Gagal Menampilkan" + e.getMessage());
        }
            
    }
    
    
    
    static ArrayList<Penjualan> getPenjualan(){
        ArrayList<Penjualan> penjualan = new ArrayList<Penjualan>();
        Penjualan d;
        
        
        try{
            String sql = "SELECT tp.id, tp.id_produk, pr.nama_produk, pr.tipe_produk, pr.harga, tp.jumlah_bayar FROM tab_penjualan tp JOIN tab_produk pr ON tp.id_produk = pr.id";
            java.sql.Connection conn = (Connection)Koneksi.getConnection();
            java.sql.Statement stm=conn.createStatement();
            java.sql.ResultSet res=stm.executeQuery(sql);
            while(res.next()){
                int id = res.getInt("id");
                int idProduk = res.getInt("id_produk");
                String namaProduk = res.getString("nama_produk");
                String tipeProduk = res.getString("tipe_produk");
                int harga = res.getInt("harga");
                int jumlahBayar = res.getInt("jumlah_bayar");
                int sisaBayar = jumlahBayar - harga;
                System.out.println(sisaBayar);
                d = new Penjualan(id, idProduk, namaProduk, tipeProduk, harga, jumlahBayar, sisaBayar);
                penjualan.add(d);
            }
        }catch(Exception e){
            Logger.getLogger(FrameProduk.Work.class.getName()).log(Level.SEVERE, null, e);
        } return penjualan;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pn_kiri = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        pn_home = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        pn_line1 = new javax.swing.JPanel();
        bttn_home = new javax.swing.JLabel();
        pn_cart = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        pn_line2 = new javax.swing.JPanel();
        bttn_cart = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        pn_shop = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        pn_line3 = new javax.swing.JPanel();
        bttn_shop = new javax.swing.JLabel();
        pn_kanan = new javax.swing.JPanel();
        pn_navbar = new javax.swing.JPanel();
        pn_dasar = new javax.swing.JPanel();
        pn_utama = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        bttnTP = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        bttnTP1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pn_kiri.setBackground(new java.awt.Color(51, 204, 0));
        pn_kiri.setPreferredSize(new java.awt.Dimension(240, 548));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Home");

        pn_home.setBackground(new java.awt.Color(255, 255, 255));
        pn_home.setPreferredSize(new java.awt.Dimension(214, 35));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icons8-home-24.png"))); // NOI18N

        pn_line1.setBackground(new java.awt.Color(255, 255, 255));
        pn_line1.setPreferredSize(new java.awt.Dimension(12, 24));

        javax.swing.GroupLayout pn_line1Layout = new javax.swing.GroupLayout(pn_line1);
        pn_line1.setLayout(pn_line1Layout);
        pn_line1Layout.setHorizontalGroup(
            pn_line1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 12, Short.MAX_VALUE)
        );
        pn_line1Layout.setVerticalGroup(
            pn_line1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 24, Short.MAX_VALUE)
        );

        bttn_home.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bttn_home.setText("Home");
        bttn_home.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bttn_homeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                bttn_homeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                bttn_homeMouseExited(evt);
            }
        });

        javax.swing.GroupLayout pn_homeLayout = new javax.swing.GroupLayout(pn_home);
        pn_home.setLayout(pn_homeLayout);
        pn_homeLayout.setHorizontalGroup(
            pn_homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_homeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pn_line1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(bttn_home, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );
        pn_homeLayout.setVerticalGroup(
            pn_homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pn_homeLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pn_homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bttn_home)
                    .addComponent(pn_line1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addContainerGap())
        );

        pn_cart.setBackground(new java.awt.Color(255, 255, 255));
        pn_cart.setPreferredSize(new java.awt.Dimension(214, 35));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icons8-cart-24.png"))); // NOI18N

        pn_line2.setBackground(new java.awt.Color(255, 255, 255));
        pn_line2.setPreferredSize(new java.awt.Dimension(12, 24));

        javax.swing.GroupLayout pn_line2Layout = new javax.swing.GroupLayout(pn_line2);
        pn_line2.setLayout(pn_line2Layout);
        pn_line2Layout.setHorizontalGroup(
            pn_line2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 12, Short.MAX_VALUE)
        );
        pn_line2Layout.setVerticalGroup(
            pn_line2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 24, Short.MAX_VALUE)
        );

        bttn_cart.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bttn_cart.setText("Rental");
        bttn_cart.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bttn_cartMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                bttn_cartMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                bttn_cartMouseExited(evt);
            }
        });

        javax.swing.GroupLayout pn_cartLayout = new javax.swing.GroupLayout(pn_cart);
        pn_cart.setLayout(pn_cartLayout);
        pn_cartLayout.setHorizontalGroup(
            pn_cartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_cartLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pn_line2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(bttn_cart, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pn_cartLayout.setVerticalGroup(
            pn_cartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pn_cartLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pn_cartLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(pn_line2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bttn_cart, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(12, 12, 12))
        );

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icons8-home-48.png"))); // NOI18N

        pn_shop.setBackground(new java.awt.Color(255, 255, 255));
        pn_shop.setPreferredSize(new java.awt.Dimension(214, 35));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMG/icons8-shop-24.png"))); // NOI18N

        pn_line3.setBackground(new java.awt.Color(255, 255, 255));
        pn_line3.setPreferredSize(new java.awt.Dimension(12, 24));

        javax.swing.GroupLayout pn_line3Layout = new javax.swing.GroupLayout(pn_line3);
        pn_line3.setLayout(pn_line3Layout);
        pn_line3Layout.setHorizontalGroup(
            pn_line3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 12, Short.MAX_VALUE)
        );
        pn_line3Layout.setVerticalGroup(
            pn_line3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 24, Short.MAX_VALUE)
        );

        bttn_shop.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bttn_shop.setText("Produk");
        bttn_shop.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bttn_shopMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                bttn_shopMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                bttn_shopMouseExited(evt);
            }
        });

        javax.swing.GroupLayout pn_shopLayout = new javax.swing.GroupLayout(pn_shop);
        pn_shop.setLayout(pn_shopLayout);
        pn_shopLayout.setHorizontalGroup(
            pn_shopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_shopLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pn_line3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addComponent(bttn_shop, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pn_shopLayout.setVerticalGroup(
            pn_shopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pn_shopLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pn_shopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pn_line3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(bttn_shop, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        javax.swing.GroupLayout pn_kiriLayout = new javax.swing.GroupLayout(pn_kiri);
        pn_kiri.setLayout(pn_kiriLayout);
        pn_kiriLayout.setHorizontalGroup(
            pn_kiriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_kiriLayout.createSequentialGroup()
                .addGroup(pn_kiriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pn_kiriLayout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pn_kiriLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(pn_home, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE))
                    .addGroup(pn_kiriLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(pn_cart, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE))
                    .addGroup(pn_kiriLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(pn_shop, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        pn_kiriLayout.setVerticalGroup(
            pn_kiriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pn_kiriLayout.createSequentialGroup()
                .addGroup(pn_kiriLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pn_kiriLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel3))
                    .addGroup(pn_kiriLayout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jLabel1)))
                .addGap(62, 62, 62)
                .addComponent(pn_home, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(pn_shop, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(pn_cart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(172, Short.MAX_VALUE))
        );

        getContentPane().add(pn_kiri, java.awt.BorderLayout.LINE_START);

        pn_kanan.setBackground(new java.awt.Color(255, 255, 255));
        pn_kanan.setMinimumSize(new java.awt.Dimension(100, 100));
        pn_kanan.setLayout(new java.awt.BorderLayout());

        pn_navbar.setBackground(new java.awt.Color(0, 153, 153));
        pn_navbar.setMinimumSize(new java.awt.Dimension(100, 80));
        pn_navbar.setPreferredSize(new java.awt.Dimension(924, 80));

        javax.swing.GroupLayout pn_navbarLayout = new javax.swing.GroupLayout(pn_navbar);
        pn_navbar.setLayout(pn_navbarLayout);
        pn_navbarLayout.setHorizontalGroup(
            pn_navbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 827, Short.MAX_VALUE)
        );
        pn_navbarLayout.setVerticalGroup(
            pn_navbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 80, Short.MAX_VALUE)
        );

        pn_kanan.add(pn_navbar, java.awt.BorderLayout.PAGE_START);

        pn_dasar.setLayout(new java.awt.BorderLayout());

        pn_utama.setBackground(new java.awt.Color(255, 255, 255));
        pn_utama.setMinimumSize(new java.awt.Dimension(100, 100));
        pn_utama.setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(560, 315));
        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setPreferredSize(new java.awt.Dimension(50, 50));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Perentalan");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel2)
                .addContainerGap(722, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        jPanel1.add(jPanel2, java.awt.BorderLayout.PAGE_START);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        bttnTP.setText("Tambah");
        bttnTP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnTPActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "No", "ID Rental", "Tgl Rental", "ID Merk", "ID Produk", "DP", "Harga", "Sisa Pembayaran", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class, java.lang.Object.class, java.lang.String.class, java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        bttnTP1.setText("Hapus");
        bttnTP1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttnTP1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 827, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(bttnTP)
                .addGap(43, 43, 43)
                .addComponent(bttnTP1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bttnTP)
                    .addComponent(bttnTP1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 331, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, java.awt.BorderLayout.CENTER);

        pn_utama.add(jPanel1, java.awt.BorderLayout.CENTER);

        pn_dasar.add(pn_utama, java.awt.BorderLayout.CENTER);

        pn_kanan.add(pn_dasar, java.awt.BorderLayout.CENTER);

        getContentPane().add(pn_kanan, java.awt.BorderLayout.CENTER);

        setSize(new java.awt.Dimension(1083, 526));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void bttn_homeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bttn_homeMouseClicked
        pn_home.setBackground(new Color(204, 204, 204));
        pn_line1.setBackground(new Color(0, 102, 153));
        
        new FrameMenu().show();
        this.dispose();

    }//GEN-LAST:event_bttn_homeMouseClicked

    private void bttn_homeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bttn_homeMouseEntered
        pn_home.setBackground(new Color(204, 204, 204));
        pn_line1.setBackground(new Color(0, 102, 153));
    }//GEN-LAST:event_bttn_homeMouseEntered

    private void bttn_homeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bttn_homeMouseExited
        pn_home.setBackground(new Color(255, 255, 255));
        pn_line1.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_bttn_homeMouseExited

    private void bttn_cartMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bttn_cartMouseEntered
        pn_cart.setBackground(new Color(204, 204, 204));
        pn_line2.setBackground(new Color(0, 102, 153));
    }//GEN-LAST:event_bttn_cartMouseEntered

    private void bttn_cartMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bttn_cartMouseExited
        pn_cart.setBackground(new Color(255, 255, 255));
        pn_line2.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_bttn_cartMouseExited

    private void bttn_shopMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bttn_shopMouseClicked
        new FrameProduk().show();
        this.dispose();
    }//GEN-LAST:event_bttn_shopMouseClicked

    private void bttn_shopMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bttn_shopMouseEntered
        pn_shop.setBackground(new Color(204, 204, 204));
        pn_line3.setBackground(new Color(0, 102, 153));
    }//GEN-LAST:event_bttn_shopMouseEntered

    private void bttn_shopMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bttn_shopMouseExited
        pn_shop.setBackground(new Color(255, 255, 255));
        pn_line3.setBackground(new Color(255, 255, 255));
    }//GEN-LAST:event_bttn_shopMouseExited

    private void bttnTPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnTPActionPerformed
        new TambahPerentalan().show();
        this.dispose();
    }//GEN-LAST:event_bttnTPActionPerformed

    private void bttn_cartMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bttn_cartMouseClicked
        new FrameRental().show();
        this.dispose();
    }//GEN-LAST:event_bttn_cartMouseClicked

    private void bttnTP1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttnTP1ActionPerformed
        // TODO add your handling code here:
        new HapusPerentalan().show();
        this.dispose();
    }//GEN-LAST:event_bttnTP1ActionPerformed

     private void load_table(){
        int no;
        DefaultTableModel model = new DefaultTableModel();
        Object[] kolom = new Object[7];
        kolom[0] = "id";
        kolom[1] = "id_produk";
        kolom[2] = "nama_produk";
        kolom[3] = "tipe_produk";
        kolom[4] = "harga";
        kolom[5] = "jumlah_bayar";
        kolom[6] = "sisa_bayar";
        
        model.setColumnIdentifiers(kolom);
        Object[] rowData1 = new Object[7];
        for(int i = 0; i < getPenjualan().size(); i++){
            
            rowData1[0] = getPenjualan().get(i).getIdPenjualan();
            rowData1[1] = getPenjualan().get(i).getIdProduk();
            rowData1[2] = getPenjualan().get(i).getNamaProduk();
            rowData1[3] = getPenjualan().get(i).getTipeProduk();
            rowData1[4] = getPenjualan().get(i).getHarga();
            rowData1[5] = getPenjualan().get(i).getJumlahBayar();
            rowData1[6] = getPenjualan().get(i).getSisaBayar();
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrameRental.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrameRental.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrameRental.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrameRental.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameRental().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bttnTP;
    private javax.swing.JButton bttnTP1;
    private javax.swing.JLabel bttn_cart;
    private javax.swing.JLabel bttn_home;
    private javax.swing.JLabel bttn_shop;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JPanel pn_cart;
    private javax.swing.JPanel pn_dasar;
    private javax.swing.JPanel pn_home;
    private javax.swing.JPanel pn_kanan;
    private javax.swing.JPanel pn_kiri;
    private javax.swing.JPanel pn_line1;
    private javax.swing.JPanel pn_line2;
    private javax.swing.JPanel pn_line3;
    private javax.swing.JPanel pn_navbar;
    private javax.swing.JPanel pn_shop;
    private javax.swing.JPanel pn_utama;
    // End of variables declaration//GEN-END:variables
}
